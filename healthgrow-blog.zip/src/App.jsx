
import React, { useState } from "react";
import { BrowserRouter as Router, Route, Routes, Link, useNavigate } from "react-router-dom";

const initialPosts = [
  {
    title: "Pehla Blog Post",
    slug: "pehla-post",
    date: "2025-08-01",
    content: "Yeh pehla blog post hai jo maine likha hai. Aap yahan apna content daal sakte hain."
  },
  {
    title: "Dusra Post",
    slug: "dusra-post",
    date: "2025-08-02",
    content: "Dusra post yahan hai. Aap naye articles aasani se daal sakte hain."
  }
];

const Header = () => (
  <header className="bg-gray-900 text-white p-4 flex justify-between items-center">
    <h1 className="text-xl font-bold"><Link to="/">Mera Blog</Link></h1>
    <nav className="space-x-4">
      <Link to="/" className="hover:underline">Home</Link>
      <Link to="/about" className="hover:underline">About</Link>
      <Link to="/terms" className="hover:underline">Terms</Link>
      <Link to="/privacy" className="hover:underline">Privacy</Link>
      <Link to="/contact" className="hover:underline">Contact</Link>
      <Link to="/new" className="hover:underline">Write</Link>
    </nav>
  </header>
);

const Footer = () => (
  <footer className="bg-gray-100 text-center p-4 text-sm text-gray-500">
    © {new Date().getFullYear()} Mera Blog. Sabhi adhikar surakshit.
  </footer>
);

const Home = ({ posts }) => (
  <main className="p-4 max-w-3xl mx-auto">
    <h2 className="text-2xl font-semibold mb-4">Naye Blog Posts</h2>
    <ul className="space-y-4">
      {posts.map((post) => (
        <li key={post.slug} className="border p-4 rounded-lg shadow">
          <Link to={`/post/${post.slug}`} className="text-xl font-bold text-blue-600 hover:underline">{post.title}</Link>
          <p className="text-gray-500 text-sm">{post.date}</p>
        </li>
      ))}
    </ul>
  </main>
);

const Post = ({ slug, posts }) => {
  const post = posts.find((p) => p.slug === slug);
  if (!post) return <div className="p-4">Post nahi mila.</div>;
  return (
    <div className="p-4 max-w-3xl mx-auto">
      <h2 className="text-3xl font-bold mb-2">{post.title}</h2>
      <p className="text-gray-500 text-sm mb-4">{post.date}</p>
      <div className="prose prose-lg max-w-none">{post.content}</div>
    </div>
  );
};

const About = () => (
  <div className="p-4 max-w-3xl mx-auto">
    <h2 className="text-2xl font-bold mb-2">About</h2>
    <p>Yeh blog ek personal platform hai jahan aap apne vichaar, kahaniyan, aur knowledge share kar sakte hain.</p>
  </div>
);

const Terms = () => (
  <div className="p-4 max-w-3xl mx-auto">
    <h2 className="text-2xl font-bold mb-2">Terms and Conditions</h2>
    <p>Is website ka istemal karne se aap hamare niyamo aur sharto se sahmat hote hain.</p>
  </div>
);

const Privacy = () => (
  <div className="p-4 max-w-3xl mx-auto">
    <h2 className="text-2xl font-bold mb-2">Privacy Policy</h2>
    <p>Hum aapki privacy ko mahattva dete hain. Aapka data safe hai.</p>
  </div>
);

const Contact = () => (
  <div className="p-4 max-w-3xl mx-auto">
    <h2 className="text-2xl font-bold mb-2">Contact</h2>
    <p>Agar aapko blog ke baare mein kuch poochna hai ya feedback dena hai, toh neeche form bhar sakte hain:</p>
    <form className="mt-4 space-y-4">
      <input type="text" placeholder="Naam" className="w-full p-2 border rounded" />
      <input type="email" placeholder="Email" className="w-full p-2 border rounded" />
      <textarea placeholder="Message" rows="4" className="w-full p-2 border rounded"></textarea>
      <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded">Bhejein</button>
    </form>
  </div>
);

const NewPost = ({ addPost }) => {
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    const slug = title.toLowerCase().replace(/\s+/g, "-").replace(/[^a-z0-9\-]/g, "");
    addPost({ title, slug, date: new Date().toISOString().split("T")[0], content });
    navigate(`/post/${slug}`);
  };

  return (
    <div className="p-4 max-w-3xl mx-auto">
      <h2 className="text-2xl font-bold mb-2">Naya Blog Post Likhein</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Title" className="w-full p-2 border rounded" required />
        <textarea value={content} onChange={(e) => setContent(e.target.value)} placeholder="Content" rows="6" className="w-full p-2 border rounded" required></textarea>
        <button type="submit" className="bg-green-600 text-white px-4 py-2 rounded">Post Publish Karein</button>
      </form>
    </div>
  );
};

function DynamicPost({ posts }) {
  const slug = window.location.pathname.split("/").pop();
  return <Post slug={slug} posts={posts} />;
}

export default function App() {
  const [posts, setPosts] = useState(initialPosts);

  const addPost = (newPost) => {
    setPosts([newPost, ...posts]);
  };

  return (
    <Router>
      <div className="min-h-screen flex flex-col">
        <Header />
        <div className="flex-grow">
          <Routes>
            <Route path="/" element={<Home posts={posts} />} />
            <Route path="/post/:slug" element={<DynamicPost posts={posts} />} />
            <Route path="/about" element={<About />} />
            <Route path="/terms" element={<Terms />} />
            <Route path="/privacy" element={<Privacy />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/new" element={<NewPost addPost={addPost} />} />
          </Routes>
        </div>
        <Footer />
      </div>
    </Router>
  );
}
